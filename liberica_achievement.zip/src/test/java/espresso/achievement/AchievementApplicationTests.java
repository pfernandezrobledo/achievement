package espresso.achievement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AchievementApplicationTests {

	@Test
	void contextLoads() {
	}

}
