package espresso.achievement.cmd.application.commandHandlers;


import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
public class CreateAchivementCommand {
    private String userKey;
    private String title;
    private String description;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date completedDate;
    private String skills;
    private Boolean isPublic;
}