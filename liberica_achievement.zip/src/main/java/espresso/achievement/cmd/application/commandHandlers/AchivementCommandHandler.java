package espresso.achievement.cmd.application.commandHandlers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import espresso.achievement.cmd.domain.contracts.IAchievementCommandHandler;
import espresso.achievement.cmd.domain.contracts.IUserRepository;
import espresso.achievement.cmd.domain.entities.UserProfile;

@Service
public class AchivementCommandHandler implements IAchievementCommandHandler {

    @Autowired
    private IUserRepository userRepository;

    public AchivementCommandHandler() {

    }

    public void handle(CreateAchivementCommand command) {

        if (command == null) {
            throw new IllegalArgumentException("The command is null");
        }

      UserProfile userProfile = userRepository.getUserByKey(command.getUserKey());
        
      System.out.println("User Profile: " + userProfile.toString());
    }
}
