package espresso.achievement.cmd.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class Skill extends Entity {
   
    @Getter
    String name;

    @Getter
    String abreviation;

    @Getter
    String description;

}
