package espresso.achievement.cmd.domain.entities;

import java.util.Date;
import java.util.List;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class Achievement {
    @Getter
    String key;

    @Getter
    OffsetDateTime timestamp;

    @Getter
    @Setter
    String title;

    @Getter
    @Setter
    String description;

    @Getter
    @Setter
    Date completedDate;

    @Getter
    @Setter
    List<Skill> skills;

    @Getter
    @Setter
    List<AchievementMedia> media;

    @Getter
    @Setter
    UserProfile userProfile;

    @Getter
    @Setter
    AchievementVisibilityStatus achievementVisibility;

    // Integer likes;

    public enum AchievementVisibilityStatus{
        UNKNOWN,
        PRIVATE,
        FRIENDS,
        FRIENDS_OF_FRIENDS,
        EVERYONE
    }
}
