package espresso.achievement.cmd.domain.entities;

import java.util.UUID;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
public abstract class Entity {
    
    @Getter
    @Setter
    private UUID id;

    @Getter
    @Setter
    private String key;

    @Getter
    @Setter
    private Date timestamp;    
}
